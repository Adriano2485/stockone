package com.example.stockone

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
